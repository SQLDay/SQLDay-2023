USE [TrackMyChanges];
GO



DROP TRIGGER IF EXISTS [tr_ServerLogs] ON ALL SERVER;
DROP TABLE IF EXISTS [dbo].[ServerLogs];






CREATE TABLE [dbo].[ServerLogs](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateTime] [datetime] NOT NULL CONSTRAINT DF_ServerLogs_DateTime DEFAULT (GETDATE()),
	[EventData] [xml] NULL,
	CONSTRAINT [PK_ServerLogs] PRIMARY KEY CLUSTERED ( [Id] ASC ) 
)
GO

CREATE NONCLUSTERED INDEX nix_ServerLogs ON [dbo].[ServerLogs] ([DateTime] ASC)  INCLUDE ([Id]);
GO





CREATE TRIGGER [tr_ServerLogs]
ON ALL SERVER 
FOR DDL_DATABASE_LEVEL_EVENTS 
AS
BEGIN
	SET NOCOUNT ON;

	IF OBJECT_ID('TrackMyChanges.dbo.DatabaseLogs') IS NOT NULL
	BEGIN

		BEGIN TRY
			DECLARE @Eventdata XML;
			SET @Eventdata = EVENTDATA();

			INSERT TrackMyChanges.dbo.ServerLogs (
			  [DateTime]
			, [EventData]
			)
			VALUES (
			  GETUTCDATE()
			, @Eventdata
			);
		END TRY

		BEGIN CATCH
			SET @Eventdata= NULL;
		END CATCH
	END
END
GO





--TEST

ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 7';
END
GO





ALTER FUNCTION dbo.fns_NewFun()
RETURNS varchar(20)
AS
BEGIN
	RETURN 'Version 7';
END
GO





SELECT * FROM TrackMyChanges.dbo.ServerLogs;





DROP TRIGGER IF EXISTS [tr_ServerLogs] ON ALL SERVER;
DROP TABLE IF EXISTS [dbo].[ServerLogs];






CREATE TABLE [dbo].[ServerLogs](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DatabaseName] [nvarchar] (128) NULL,
	[DateTime] [datetime] NOT NULL CONSTRAINT DF_ServerLogs_DateTime DEFAULT (GETDATE()),
	[ServerName] [nvarchar](128) NULL,
	[ServiceName] [nvarchar](128) NULL,
	[SPID] [int] NULL,
	[SourceHostName] [nvarchar](128) NULL,
	[LoginName] [nvarchar](128) NULL,
	[UserName] [nvarchar](128) NULL,
	[SchemaName] [nvarchar](128) NULL,
	[ObjectName] [nvarchar](128) NULL,
	[TargetObjectName] [nvarchar](128) NULL,
	[EventType] [nvarchar](128) NULL,
	[ObjectType] [nvarchar](128) NULL,
	[TargetObjectType] [nvarchar](128) NULL,
	[EventData] [xml] NULL,
	CONSTRAINT [PK_ServerLogs] PRIMARY KEY CLUSTERED ( [Id] ASC ) 
)
GO

CREATE NONCLUSTERED INDEX nix_ServerLogs ON [dbo].[ServerLogs] ([DateTime] ASC)  INCLUDE ([Id]);
GO




CREATE TRIGGER [tr_ServerLogs]
ON ALL SERVER 
FOR DDL_DATABASE_LEVEL_EVENTS 
AS
BEGIN
	SET NOCOUNT ON;

	-- Store session SET options
	DECLARE @ANSI_NULLS	bit;
	DECLARE @ANSI_PADDING bit;
	DECLARE @ANSI_WARNINGS bit;
	DECLARE @ARITHABORT bit;
	DECLARE @CONCAT_NULL_YIELDS_NULL bit;
	DECLARE @NUMERIC_ROUNDABORT bit;
	DECLARE @QUOTED_IDENTIFIER bit;

	DECLARE @options INT;
	SELECT @options = @@OPTIONS;

	IF ( (8 & @options) = 8 ) BEGIN SET @ANSI_WARNINGS=1 END ELSE BEGIN SET @ANSI_WARNINGS=0 END;
	IF ( (16 & @options) = 16 ) BEGIN SET @ANSI_PADDING=1 END ELSE BEGIN SET @ANSI_PADDING=0 END;
	IF ( (32 & @options) = 32 ) BEGIN SET @ANSI_NULLS=1 END ELSE BEGIN SET @ANSI_NULLS=0 END;
	IF ( (64 & @options) = 64 ) BEGIN SET @ARITHABORT=1 END ELSE BEGIN SET @ARITHABORT=0 END;
	IF ( (256 & @options) = 256 ) BEGIN SET @QUOTED_IDENTIFIER=1 END ELSE BEGIN SET @QUOTED_IDENTIFIER=0 END;
	IF ( (4096 & @options) = 4096 ) BEGIN SET @CONCAT_NULL_YIELDS_NULL=1 END ELSE BEGIN SET @CONCAT_NULL_YIELDS_NULL=0 END;
	IF ( (8192 & @options) = 8192 ) BEGIN SET @NUMERIC_ROUNDABORT=1 END ELSE BEGIN SET @NUMERIC_ROUNDABORT=0 END;

	-- Set SET options required for XML Data Type
	SET ANSI_NULLS ON;
	SET ANSI_PADDING ON;
	SET ANSI_WARNINGS ON;
	SET ARITHABORT ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET NUMERIC_ROUNDABORT OFF;
	SET QUOTED_IDENTIFIER ON;


	IF OBJECT_ID('TrackMyChanges.dbo.ServerLogs') IS NOT NULL
	BEGIN

		BEGIN TRY

			DECLARE @Eventdata XML;
			SET @Eventdata = EVENTDATA();

			INSERT TrackMyChanges.dbo.ServerLogs (
			  [DatabaseName]
			, [DateTime]
			, [ServerName]
			, [ServiceName]
			, [SPID]
			, [SourceHostName]
			, [LoginName]
			, [UserName]
			, [SchemaName]
			, [ObjectName]
			, [TargetObjectName]
			, [EventType]
			, [ObjectType]
			, [TargetObjectType]
			, [EventData]
			)
			VALUES (
			  @Eventdata.value('(/EVENT_INSTANCE/DatabaseName)[1]', 'nvarchar(128)')
			, GETUTCDATE()
			, @@SERVERNAME
			, @@SERVICENAME
			, @Eventdata.value('(/EVENT_INSTANCE/SPID)[1]', 'int')
			, HOST_NAME()
			, @Eventdata.value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/UserName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/SchemaName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/ObjectName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/TargetObjectName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/EventType)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/ObjectType)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/TargetObjectType)[1]', 'nvarchar(128)')
			, @Eventdata
			);

		END TRY

		BEGIN CATCH
			SET @Eventdata= NULL;
		END CATCH

	-- Revert session SET options
	IF @ANSI_WARNINGS=1 BEGIN SET ANSI_WARNINGS ON END ELSE BEGIN SET ANSI_WARNINGS OFF END;
	IF @ANSI_PADDING=1 BEGIN SET ANSI_PADDING ON END ELSE BEGIN SET ANSI_PADDING OFF END;
	IF @ANSI_NULLS=1 BEGIN SET ANSI_NULLS ON END ELSE BEGIN SET ANSI_NULLS OFF END;
	IF @ARITHABORT=1 BEGIN SET ARITHABORT ON END ELSE BEGIN SET ARITHABORT OFF END;
	IF @QUOTED_IDENTIFIER=1 BEGIN SET QUOTED_IDENTIFIER ON END ELSE BEGIN SET QUOTED_IDENTIFIER OFF END;
	IF @CONCAT_NULL_YIELDS_NULL=1 BEGIN SET CONCAT_NULL_YIELDS_NULL ON END ELSE BEGIN SET CONCAT_NULL_YIELDS_NULL OFF END;
	IF @NUMERIC_ROUNDABORT=1 BEGIN SET NUMERIC_ROUNDABORT ON END ELSE BEGIN SET NUMERIC_ROUNDABORT OFF END;

	END
END
GO




--TEST

ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 8';
END
GO





ALTER FUNCTION dbo.fns_NewFun()
RETURNS varchar(20)
AS
BEGIN
	RETURN 'Version 8';
END
GO




SELECT * FROM dbo.ServerLogs;