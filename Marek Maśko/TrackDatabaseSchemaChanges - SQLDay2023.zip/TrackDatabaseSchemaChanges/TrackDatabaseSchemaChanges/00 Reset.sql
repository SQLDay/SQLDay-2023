USE master;
GO

DROP DATABASE IF EXISTS TrackMyChanges;
GO

EXEC sp_configure 'show advanced options', 1
RECONFIGURE

EXEC sp_configure 'default trace enabled', 0;
RECONFIGURE

EXEC sp_configure 'default trace enabled', 1;
RECONFIGURE

EXEC sp_configure 'show advanced options', 0
RECONFIGURE