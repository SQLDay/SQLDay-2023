USE [TrackMyChanges];
GO





SELECT * FROM fn_dblog(null, null);





SELECT [Current LSN],
[Operation],
[Transaction ID],
[SPID],
[Begin Time],
[Transaction Name],
SUSER_SNAME([Transaction SID]) AS [Login],
[Xact ID],
[End Time],
[Lock Information],
[AllocUnitName],
[Description]
FROM fn_dblog(null, null)
WHERE [Operation] = 'LOP_BEGIN_XACT'
AND [Transaction Name] NOT IN ('AutoCreateQPStats', 'SplitPage', 'QDS base transaction', 'QDS batch', 'Allocate Root', 'AllocFirstPage', 'UpdateQPStats', 'QDS nested transaction', 'AllocMixedExtent', 'BTreeMgr::SplitRoo', 'Allocate Text Root', 'Allocate Text Root')
ORDER BY [Current LSN] ASC



--Second ALTER Function Transaction ID
SELECT [Current LSN],
[Operation],
[Transaction ID],
[SPID],
[Begin Time],
[Transaction Name],
SUSER_SNAME([Transaction SID]) AS [Login],
[Xact ID],
[End Time],
[Lock Information],
[AllocUnitName],
[Description]
FROM fn_dblog(null, null) WHERE [Transaction ID] = '0000:000003e6'

 


 --Find Function
SELECT * FROM sys.objects WHERE object_id = 965578478
--HoBt 0:ACQUIRE_LOCK_SCH_M OBJECT: 12:965578478:0 




SELECT [Current LSN],
[Operation],
[Transaction ID],
[SPID],
[Begin Time],
[Transaction Name],
SUSER_SNAME([Transaction SID]) AS [Login],
[Xact ID],
[End Time],
[Lock Information],
[AllocUnitName],
[Description]
FROM fn_dblog(null, null)
WHERE [Operation] = 'LOP_BEGIN_XACT'
AND [Transaction Name] NOT IN ('AutoCreateQPStats', 'SplitPage', 'QDS base transaction', 'QDS batch', 'Allocate Root', 'AllocFirstPage', 'UpdateQPStats', 'QDS nested transaction', 'AllocMixedExtent', 'BTreeMgr::SplitRoo', 'Allocate Text Root', 'Allocate Text Root')
ORDER BY [Current LSN] ASC






--Second ALTER Triger Transaction ID
SELECT [Current LSN],
[Operation],
[Transaction ID],
[SPID],
[Begin Time],
[Transaction Name],
SUSER_SNAME([Transaction SID]) AS [Login],
[Xact ID],
[End Time],
[Lock Information],
[AllocUnitName],
[Description]
FROM fn_dblog(null, null) WHERE [Transaction ID] = '0000:000003e7'
--
 


 --Find Trigger
SELECT * FROM sys.objects WHERE object_id = 933578364
--HoBt 0:ACQUIRE_LOCK_SCH_M OBJECT: 12:933578364:0 
SELECT * FROM sys.objects WHERE object_id = 901578250
--HoBt 0:ACQUIRE_LOCK_SCH_M OBJECT: 12:901578250:0 




----------------------------------------
SELECT [Current LSN],
[Operation],
[Transaction ID],
[SPID],
[Begin Time],
[Transaction Name],
SUSER_SNAME([Transaction SID]) AS [Login],
[Xact ID],
[End Time],
[Lock Information],
[AllocUnitName],
[Description]
, CAST(SUBSTRING([RowLog Contents 0],33,LEN([RowLog Contents 0])) AS varchar(8000)) --2
FROM fn_dblog(null, null)
WHERE [Transaction ID] = '0000:000003e6' -- Function
AND [AllocUnitName] = 'sys.sysobjvalues.clst' --1
ORDER BY [Current LSN] ASC



-- Show DROPOBJ
SELECT [Current LSN],
[Operation],
[Transaction ID],
[SPID],
[Begin Time],
[Transaction Name],
SUSER_SNAME([Transaction SID]) AS [Login],
[Xact ID],
[End Time],
[Lock Information],
[AllocUnitName],
[Description]
FROM fn_dblog(null, null)
WHERE [Operation] = 'LOP_BEGIN_XACT'
AND [Transaction Name] NOT IN ('AutoCreateQPStats', 'SplitPage', 'QDS base transaction', 'QDS batch', 'Allocate Root', 'AllocFirstPage', 'UpdateQPStats', 'QDS nested transaction', 'AllocMixedExtent', 'BTreeMgr::SplitRoo', 'Allocate Text Root', 'Allocate Text Root')
ORDER BY [Current LSN] ASC

SELECT [Current LSN],
[Operation],
[Transaction ID],
[SPID],
[Begin Time],
[Transaction Name],
SUSER_SNAME([Transaction SID]) AS [Login],
[Xact ID],
[End Time],
[Lock Information],
[AllocUnitName],
[Description]
, CAST(SUBSTRING([RowLog Contents 0],33,LEN([RowLog Contents 0])) AS varchar(8000)) --2
FROM fn_dblog(null, null)
WHERE [Transaction ID] = '0000:000003e5' -- DROPOBJ
AND [AllocUnitName] = 'sys.sysobjvalues.clst' --1
ORDER BY [Current LSN] ASC