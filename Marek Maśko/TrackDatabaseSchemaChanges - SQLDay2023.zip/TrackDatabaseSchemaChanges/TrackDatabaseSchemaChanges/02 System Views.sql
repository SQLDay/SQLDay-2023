USE [TrackMyChanges];
GO





SELECT * FROM sys.tables;





SELECT * FROM sys.key_constraints





SELECT * FROM sys.indexes
WHERE object_id = object_id('NewTable');





SELECT * FROM sys.triggers;





SELECT * FROM sys.procedures;





SELECT * FROM sys.functions;





SELECT * FROM sys.sql_modules;





SELECT * FROM sys.objects WHERE is_ms_shipped = 0;