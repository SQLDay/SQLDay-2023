USE [master];
GO

DROP TRIGGER IF EXISTS [tr_ServerLogs] ON ALL SERVER;
DROP DATABASE IF EXISTS TrackMyChanges;


--Remove XE session
DROP EVENT SESSION [CaptureSchemaChanges] ON SERVER 
GO

USE [master]
GO

ALTER SERVER AUDIT [SchemaChangesAudit] 
WITH (STATE = OFF);  
GO

DROP SERVER AUDIT [SchemaChangesAudit]
GO

--??
DROP EVENT NOTIFICATION NotifyDDLEvents ON DATABASE
GO 
DROP SERVICE [//TrackMyChanges/EventNotificationService] 
GO 
DROP QUEUE dbo.EventNotificationQueue 
GO





USE msdb ;
GO

EXEC dbo.sp_delete_alert
   @name = N'WMITest' ;
GO