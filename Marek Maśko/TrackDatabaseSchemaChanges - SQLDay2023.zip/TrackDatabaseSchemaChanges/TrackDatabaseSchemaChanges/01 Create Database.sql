USE master;
GO

DROP DATABASE IF EXISTS TrackMyChanges;
GO

CREATE DATABASE TrackMyChanges;
GO

BACKUP DATABASE TrackMyChanges TO DISK='C:\Temp\TrackMyChanges.bak';
GO





USE TrackMyChanges;
GO

CREATE TABLE dbo.NewTable (
	Id int IDENTITY NOT NULL,
	Col1 varchar(20) NULL,
	Col2 varchar(20) NULL
);





ALTER TABLE dbo.NewTable
ADD CONSTRAINT pk_NewTable PRIMARY KEY CLUSTERED (Id);





CREATE INDEX ix_NewTable_Col1 ON dbo.NewTable (Col1);
GO





CREATE TRIGGER dbo.tr_NewTableIns
ON dbo.NewTable
AFTER INSERT
AS
BEGIN
	SELECT 'Version 1';
END
GO





CREATE PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 1';
END
GO





CREATE FUNCTION dbo.fns_NewFun()
RETURNS varchar(20)
AS
BEGIN
	RETURN 'Version 1';
END
GO





--ALTER
ALTER TRIGGER dbo.tr_NewTableIns
ON dbo.NewTable
AFTER INSERT
AS
BEGIN
	SELECT 'Version 2';
END
GO





ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 2';
END
GO





ALTER FUNCTION dbo.fns_NewFun()
RETURNS varchar(20)
AS
BEGIN
	RETURN 'Version 2';
END
GO





--DROP
DROP TRIGGER dbo.tr_NewTableIns;
GO





/*
DROP PROCEDURE dbo.usp_NewProc;
GO

DROP FUNCTION dbo.fns_NewFun;
GO

DROP INDEX ix_NewTable_Col1 ON dbo.NewTable;
GO

ALTER TABLE dbo.NewTable
DROP CONSTRAINT pk_NewTable;

DROP TABLE dbo.NewTable;

USE master;
GO

DROP DATABASE TrackMyChanges;
*/