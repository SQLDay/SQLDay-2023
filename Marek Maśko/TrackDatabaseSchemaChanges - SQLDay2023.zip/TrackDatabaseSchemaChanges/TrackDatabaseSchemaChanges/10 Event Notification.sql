USE [master];
GO

--Check if the database is enabled for Service Broker
--If not then enable it 
SELECT * FROM sys.databases WHERE [name] = 'TrackMyChanges' AND is_broker_enabled = 0;

ALTER DATABASE [TrackMyChanges] SET ENABLE_BROKER; 
GO





USE [TrackMyChanges] 
GO





--Create a queue which will hold the tracked information 
CREATE QUEUE dbo.EventNotificationQueue 
GO 





--Check if the queue is created or not 
SELECT * FROM sys.service_queues 
WHERE name = 'EventNotificationQueue' 
GO





--Create a service on which tracked information will be sent 
CREATE SERVICE [//TrackMyChanges/EventNotificationService] 
ON QUEUE dbo.EventNotificationQueue 
([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]) 
GO





--Check if the service is created or not 
SELECT * FROM sys.services 
WHERE name = '//TrackMyChanges/EventNotificationService' 
GO





--Create a notification to track create table command
CREATE EVENT NOTIFICATION NotifyDDLEvents 
ON DATABASE 
FOR DDL_DATABASE_LEVEL_EVENTS 
TO SERVICE '//TrackMyChanges/EventNotificationService' , 'current database' 
GO 





--Check if the above notification is created or not 
SELECT * FROM sys.event_notifications 
WHERE [name] = 'NotifyDDLEvents'; 
GO




--TEST
ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 10';
END
GO


DROP FUNCTION dbo.fns_NewFun;
GO


CREATE FUNCTION dbo.fns_NewFun()
RETURNS varchar(20)
AS
BEGIN
	RETURN 'Version 10';
END
GO





--Review if the events were tracked in queue 
SELECT CAST(message_body AS XML) AS message_in_xml 
FROM dbo.EventNotificationQueue 
GO




-- Receive messages
DECLARE @TargetDialogHandle UNIQUEIDENTIFIER;
DECLARE @EventMessage XML; 
DECLARE @EventMessageTypeName sysname; 
WAITFOR 
( RECEIVE TOP(1) 
@TargetDialogHandle = conversation_handle, 
@EventMessage = CONVERT(XML, message_body), 
@EventMessageTypeName = message_type_name 
FROM dbo.EventNotificationQueue 
), TIMEOUT 1000; 
SELECT @TargetDialogHandle AS DialogHandle, @EventMessageTypeName AS MessageTypeName, 
@EventMessage.value('(/EVENT_INSTANCE/EventType)[1]', 'varchar(128)' ) as EventType,
@EventMessage.value('(/EVENT_INSTANCE/PostTime)[1]', 'varchar(128)' ) as PostTime, 
@EventMessage.value('(/EVENT_INSTANCE/ServerName)[1]', 'varchar(128)' ) as ServerName, 
@EventMessage.value('(/EVENT_INSTANCE/DatabaseName)[1]', 'varchar(128)' ) as DatabaseName, 
@EventMessage.value('(/EVENT_INSTANCE/LoginName)[1]', 'varchar(128)' ) as LoginName, 
@EventMessage.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]','nvarchar(max)') AS TSQLCommand, 
@EventMessage.value('(/EVENT_INSTANCE/TextData)[1]', 'varchar(128)' ) AS TextData, 
@EventMessage.value('(/EVENT_INSTANCE/Severity)[1]', 'varchar(128)' ) AS Severity, 
@EventMessage.value('(/EVENT_INSTANCE/Error)[1]', 'varchar(128)' ) AS ErrorNumber;


--Create table

DROP TABLE IF EXISTS [dbo].[DatabaseLogs];

CREATE TABLE [dbo].[DatabaseLogs](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateTime] [datetime] NOT NULL CONSTRAINT DF_DatabaseLogs_DateTime DEFAULT (GETDATE()),
	[ServerName] [nvarchar](128) NULL,
	[ServiceName] [nvarchar](128) NULL,
	[SPID] [int] NULL,
	[SourceHostName] [nvarchar](128) NULL,
	[LoginName] [nvarchar](128) NULL,
	[UserName] [nvarchar](128) NULL,
	[SchemaName] [nvarchar](128) NULL,
	[ObjectName] [nvarchar](128) NULL,
	[TargetObjectName] [nvarchar](128) NULL,
	[EventType] [nvarchar](128) NULL,
	[ObjectType] [nvarchar](128) NULL,
	[TargetObjectType] [nvarchar](128) NULL,
	[EventData] [xml] NULL,
	CONSTRAINT [PK_DatabaseLogs] PRIMARY KEY CLUSTERED ( [Id] ASC ) 
)
GO

CREATE NONCLUSTERED INDEX nix_DatabaseLogs ON [dbo].[DatabaseLogs] ([DateTime] ASC)  INCLUDE ([Id]);
GO


--Activation Stored Procedure
CREATE PROCEDURE dbo.usp_EventNotificationActivation
AS
BEGIN
	SET NOCOUNT ON;
 
	DECLARE @messageContent XML;
	DECLARE @messageTypeName sysname;
 
	WHILE (1=1)
	BEGIN
		BEGIN TRANSACTION;
 
		WAITFOR
		(
			RECEIVE TOP (1)
			@messageContent = CAST(message_body AS XML),
			@messageTypeName = message_type_name
			FROM dbo.EventNotificationQueue 
		), TIMEOUT 5000;
 
		IF (@@ROWCOUNT = 0)
		BEGIN
			ROLLBACK TRANSACTION;
			BREAK;
		END
 
		IF @messageTypeName = N'http://schemas.microsoft.com/SQL/Notifications/EventNotification'
		BEGIN
			BEGIN TRY

				INSERT dbo.DatabaseLogs (
				  [DateTime]
				, [ServerName]
				, [ServiceName]
				, [SPID]
				, [SourceHostName]
				, [LoginName]
				, [UserName]
				, [SchemaName]
				, [ObjectName]
				, [TargetObjectName]
				, [EventType]
				, [ObjectType]
				, [TargetObjectType]
				, [EventData]
				)
				VALUES (
				  @messageContent.value('(/EVENT_INSTANCE/PostTime)[1]', 'varchar(128)' )
				, @@SERVERNAME
				, @@SERVICENAME
				, @messageContent.value('(/EVENT_INSTANCE/SPID)[1]', 'int' )
				, HOST_NAME()
				, @messageContent.value('(/EVENT_INSTANCE/LoginName)[1]', 'varchar(128)' )
				, @messageContent.value('(/EVENT_INSTANCE/UserName)[1]', 'varchar(128)' )
				, @messageContent.value('(/EVENT_INSTANCE/SchemaName)[1]', 'varchar(128)' )
				, @messageContent.value('(/EVENT_INSTANCE/ObjectName)[1]', 'nvarchar(128)')
				, @messageContent.value('(/EVENT_INSTANCE/TargetObjectName)[1]', 'nvarchar(128)')
				, @messageContent.value('(/EVENT_INSTANCE/EventType)[1]', 'nvarchar(128)')
				, @messageContent.value('(/EVENT_INSTANCE/ObjectType)[1]', 'nvarchar(128)')
				, @messageContent.value('(/EVENT_INSTANCE/TargetObjectType)[1]', 'nvarchar(128)')
				, @messageContent
				);
			END TRY

			BEGIN CATCH
				SET @messageContent= NULL;
			END CATCH

		END;
		COMMIT TRANSACTION;
	END
END;

-- Add Activation Stored Proceudre to Queue
ALTER QUEUE dbo.EventNotificationQueue  
    WITH ACTIVATION ( 
		STATUS = ON,
		MAX_QUEUE_READERS = 10,
        PROCEDURE_NAME = dbo.usp_EventNotificationActivation,  
        EXECUTE AS SELF) ; 
GO


--TEST
ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 11';
END
GO


DROP FUNCTION dbo.fns_NewFun;
GO


CREATE FUNCTION dbo.fns_NewFun()
RETURNS varchar(20)
AS
BEGIN
	RETURN 'Version 11';
END
GO

SELECT * FROM dbo.DatabaseLogs;


--Cleanup
DROP EVENT NOTIFICATION NotifyDDLEvents ON DATABASE
GO 
DROP SERVICE [//TrackMyChanges/EventNotificationService] 
GO 
DROP QUEUE dbo.EventNotificationQueue 
GO