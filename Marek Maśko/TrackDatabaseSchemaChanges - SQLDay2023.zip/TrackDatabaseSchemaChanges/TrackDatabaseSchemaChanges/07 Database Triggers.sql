USE [TrackMyChanges];
GO





-- CREATE Database DDL trigger - version 1

DROP TABLE IF EXISTS [dbo].[DatabaseLogs];
DROP TRIGGER IF EXISTS [tr_DatabaseLogs] ON DATABASE;





CREATE TABLE [dbo].[DatabaseLogs](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateTime] [datetime] NOT NULL CONSTRAINT DF_DatabaseLogs_DateTime DEFAULT (GETDATE()),
	[EventData] [xml] NULL,
	CONSTRAINT [PK_DatabaseLogs] PRIMARY KEY CLUSTERED ( [Id] ASC ) 
)
GO

CREATE NONCLUSTERED INDEX nix_DatabaseLogs ON [dbo].[DatabaseLogs] ([DateTime] ASC)  INCLUDE ([Id]);
GO





CREATE TRIGGER [tr_DatabaseLogs]
ON DATABASE 
FOR DDL_DATABASE_LEVEL_EVENTS 
AS
BEGIN
	SET NOCOUNT ON;

	IF OBJECT_ID('dbo.DatabaseLogs') IS NOT NULL
	BEGIN

		BEGIN TRY
			DECLARE @Eventdata XML;
			SET @Eventdata = EVENTDATA();

			INSERT dbo.DatabaseLogs (
			  [DateTime]
			, [EventData]
			)
			VALUES (
			  GETUTCDATE()
			, @Eventdata
			);
		END TRY

		BEGIN CATCH
			SET @Eventdata= NULL;
		END CATCH
	END
END
GO





--TEST

ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 4';
END
GO





CREATE FUNCTION dbo.fns_NewFun()
RETURNS varchar(20)
AS
BEGIN
	RETURN 'Version 4';
END
GO





-- Check Log
SELECT * FROM dbo.DatabaseLogs;





-- CREATE Database DDL trigger - version 2
DROP TABLE IF EXISTS [dbo].[DatabaseLogs];
DROP TRIGGER IF EXISTS [tr_DatabaseLogs] ON DATABASE;





CREATE TABLE [dbo].[DatabaseLogs](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DateTime] [datetime] NOT NULL CONSTRAINT DF_DatabaseLogs_DateTime DEFAULT (GETDATE()),
	[ServerName] [nvarchar](128) NULL,
	[ServiceName] [nvarchar](128) NULL,
	[SPID] [int] NULL,
	[SourceHostName] [nvarchar](128) NULL,
	[LoginName] [nvarchar](128) NULL,
	[UserName] [nvarchar](128) NULL,
	[SchemaName] [nvarchar](128) NULL,
	[ObjectName] [nvarchar](128) NULL,
	[TargetObjectName] [nvarchar](128) NULL,
	[EventType] [nvarchar](128) NULL,
	[ObjectType] [nvarchar](128) NULL,
	[TargetObjectType] [nvarchar](128) NULL,
	[EventData] [xml] NULL,
	CONSTRAINT [PK_DatabaseLogs] PRIMARY KEY CLUSTERED ( [Id] ASC ) 
)
GO

CREATE NONCLUSTERED INDEX nix_DatabaseLogs ON [dbo].[DatabaseLogs] ([DateTime] ASC)  INCLUDE ([Id]);
GO





CREATE TRIGGER [tr_DatabaseLogs]
ON DATABASE 
FOR DDL_DATABASE_LEVEL_EVENTS 
AS
BEGIN
	SET NOCOUNT ON;

	IF OBJECT_ID('dbo.DatabaseLogs') IS NOT NULL
	BEGIN
		BEGIN TRY
			DECLARE @Eventdata XML;
			SET @Eventdata = EVENTDATA();

			INSERT dbo.DatabaseLogs (
			  [DateTime]
			, [ServerName]
			, [ServiceName]
			, [SPID]
			, [SourceHostName]
			, [LoginName]
			, [UserName]
			, [SchemaName]
			, [ObjectName]
			, [TargetObjectName]
			, [EventType]
			, [ObjectType]
			, [TargetObjectType]
			, [EventData]
			)
			VALUES (
			  GETUTCDATE()
			, @@SERVERNAME
			, @@SERVICENAME
			, @Eventdata.value('(/EVENT_INSTANCE/SPID)[1]', 'int')
			, HOST_NAME()
			, @Eventdata.value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/UserName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/SchemaName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/ObjectName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/TargetObjectName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/EventType)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/ObjectType)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/TargetObjectType)[1]', 'nvarchar(128)')
			, @Eventdata
			);
		END TRY

		BEGIN CATCH
			SET @Eventdata= NULL;
		END CATCH
	END
END
GO





-- TEST
ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 5';
END
GO





DROP FUNCTION dbo.fns_NewFun;
GO





CREATE FUNCTION dbo.fns_NewFun()
RETURNS varchar(20)
AS
BEGIN
	RETURN 'Version 5';
END
GO




-- Check Log
SELECT * FROM dbo.DatabaseLogs;





-- One more TEST
SET ANSI_PADDING OFF;

DROP TRIGGER tr_NewTableIns;
GO

ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 6';
END
GO





SELECT * FROM dbo.DatabaseLogs;




EXEC sp_helptext 'usp_NewProc';





SET ANSI_PADDING ON;





--Final version
DROP TRIGGER IF EXISTS [tr_DatabaseLogs] ON DATABASE;
GO

CREATE TRIGGER [tr_DatabaseLogs]
ON DATABASE 
FOR DDL_DATABASE_LEVEL_EVENTS 
AS
BEGIN
	SET NOCOUNT ON;

	-- Store session SET options
	DECLARE @ANSI_NULLS	bit;
	DECLARE @ANSI_PADDING bit;
	DECLARE @ANSI_WARNINGS bit;
	DECLARE @ARITHABORT bit;
	DECLARE @CONCAT_NULL_YIELDS_NULL bit;
	DECLARE @NUMERIC_ROUNDABORT bit;
	DECLARE @QUOTED_IDENTIFIER bit;

	DECLARE @options INT;
	SELECT @options = @@OPTIONS;

	IF ( (8 & @options) = 8 ) BEGIN SET @ANSI_WARNINGS=1 END ELSE BEGIN SET @ANSI_WARNINGS=0 END;
	IF ( (16 & @options) = 16 ) BEGIN SET @ANSI_PADDING=1 END ELSE BEGIN SET @ANSI_PADDING=0 END;
	IF ( (32 & @options) = 32 ) BEGIN SET @ANSI_NULLS=1 END ELSE BEGIN SET @ANSI_NULLS=0 END;
	IF ( (64 & @options) = 64 ) BEGIN SET @ARITHABORT=1 END ELSE BEGIN SET @ARITHABORT=0 END;
	IF ( (256 & @options) = 256 ) BEGIN SET @QUOTED_IDENTIFIER=1 END ELSE BEGIN SET @QUOTED_IDENTIFIER=0 END;
	IF ( (4096 & @options) = 4096 ) BEGIN SET @CONCAT_NULL_YIELDS_NULL=1 END ELSE BEGIN SET @CONCAT_NULL_YIELDS_NULL=0 END;
	IF ( (8192 & @options) = 8192 ) BEGIN SET @NUMERIC_ROUNDABORT=1 END ELSE BEGIN SET @NUMERIC_ROUNDABORT=0 END;

	-- Set SET options required for XML Data Type
	SET ANSI_NULLS ON;
	SET ANSI_PADDING ON;
	SET ANSI_WARNINGS ON;
	SET ARITHABORT ON;
	SET CONCAT_NULL_YIELDS_NULL ON;
	SET NUMERIC_ROUNDABORT OFF;
	SET QUOTED_IDENTIFIER ON;


	IF OBJECT_ID('dbo.DatabaseLogs') IS NOT NULL
	BEGIN

		BEGIN TRY

			DECLARE @Eventdata XML;
			SET @Eventdata = EVENTDATA();

			INSERT dbo.DatabaseLogs (
			  [DateTime]
			, [ServerName]
			, [ServiceName]
			, [SPID]
			, [SourceHostName]
			, [LoginName]
			, [UserName]
			, [SchemaName]
			, [ObjectName]
			, [TargetObjectName]
			, [EventType]
			, [ObjectType]
			, [TargetObjectType]
			, [EventData]
			)
			VALUES (
			  GETUTCDATE()
			, @@SERVERNAME
			, @@SERVICENAME
			, @Eventdata.value('(/EVENT_INSTANCE/SPID)[1]', 'int')
			, HOST_NAME()
			, @Eventdata.value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/UserName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/SchemaName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/ObjectName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/TargetObjectName)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/EventType)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/ObjectType)[1]', 'nvarchar(128)')
			, @Eventdata.value('(/EVENT_INSTANCE/TargetObjectType)[1]', 'nvarchar(128)')
			, @Eventdata
			);

		END TRY

		BEGIN CATCH
			SET @Eventdata= NULL;
		END CATCH

	-- Revert session SET options
	IF @ANSI_WARNINGS=1 BEGIN SET ANSI_WARNINGS ON END ELSE BEGIN SET ANSI_WARNINGS OFF END;
	IF @ANSI_PADDING=1 BEGIN SET ANSI_PADDING ON END ELSE BEGIN SET ANSI_PADDING OFF END;
	IF @ANSI_NULLS=1 BEGIN SET ANSI_NULLS ON END ELSE BEGIN SET ANSI_NULLS OFF END;
	IF @ARITHABORT=1 BEGIN SET ARITHABORT ON END ELSE BEGIN SET ARITHABORT OFF END;
	IF @QUOTED_IDENTIFIER=1 BEGIN SET QUOTED_IDENTIFIER ON END ELSE BEGIN SET QUOTED_IDENTIFIER OFF END;
	IF @CONCAT_NULL_YIELDS_NULL=1 BEGIN SET CONCAT_NULL_YIELDS_NULL ON END ELSE BEGIN SET CONCAT_NULL_YIELDS_NULL OFF END;
	IF @NUMERIC_ROUNDABORT=1 BEGIN SET NUMERIC_ROUNDABORT ON END ELSE BEGIN SET NUMERIC_ROUNDABORT OFF END;

	END
END
GO





SET ANSI_PADDING OFF;

DROP TRIGGER tr_NewTableIns;
GO

ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 6';
END
GO





SELECT * FROM dbo.DatabaseLogs;





EXEC sp_helptext 'usp_NewProc'





SET ANSI_PADDING ON;