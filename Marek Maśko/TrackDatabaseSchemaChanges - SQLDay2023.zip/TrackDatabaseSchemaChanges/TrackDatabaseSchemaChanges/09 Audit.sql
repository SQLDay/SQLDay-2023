-- Create new Audit: SchemaChangesAudit
-- with SCHEMA_OBJECT_CHANGE_GROUP



USE [TrackMyChanges];
GO




ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 9';
END
GO


DROP FUNCTION dbo.fns_NewFun;
GO


CREATE FUNCTION dbo.fns_NewFun()
RETURNS varchar(20)
AS
BEGIN
	RETURN 'Version 9';
END
GO




--Check Audit Log with GUI





--Check Audit Log with T-SQL
SELECT * FROM sys.server_file_audits WHERE [name] = 'SchemaChangesAudit';
GO


DECLARE @file varchar(255);
SELECT @file = log_file_path + REPLACE(log_file_name, '.sqlaudit', '*.sqlaudit') FROM sys.server_file_audits WHERE [name] = 'SchemaChangesAudit';

SELECT event_time, session_id, server_principal_name, database_name, schema_name, object_name, statement, host_name, application_name 
FROM sys.fn_get_audit_file(@file, default, default)
ORDER BY event_time;
GO



/*
DROP PROCEDURE dbo.usp_NewProc;
GO

DROP FUNCTION dbo.fns_NewFun;
GO

DROP INDEX ix_NewTable_Col1 ON dbo.NewTable;
GO

ALTER TABLE dbo.NewTable
DROP CONSTRAINT pk_NewTable;

DROP TABLE dbo.NewTable;
--*/





/*
--Create Server Audit with T-SQL:
USE [master]
GO

CREATE SERVER AUDIT [SchemaChangesAudit]
TO FILE 
(	FILEPATH = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\Log\'
	,MAXSIZE = 0 MB
	,MAX_ROLLOVER_FILES = 2147483647
	,RESERVE_DISK_SPACE = OFF
) WITH (QUEUE_DELAY = 1000, ON_FAILURE = CONTINUE, AUDIT_GUID = 'c0c025fd-af19-44c9-92b8-3ecb966beabd')
ALTER SERVER AUDIT [SchemaChangesAudit] WITH (STATE = OFF);
GO

USE [TrackMyChanges]
GO

CREATE DATABASE AUDIT SPECIFICATION [SchemaChangesDatabaseAudit]
FOR SERVER AUDIT [SchemaChangesAudit]
ADD (SCHEMA_OBJECT_CHANGE_GROUP)
WITH (STATE = OFF);
GO

ALTER DATABASE AUDIT SPECIFICATION [SchemaChangesDatabaseAudit]  
WITH (STATE = ON);  
GO

USE [master]
GO

ALTER SERVER AUDIT [SchemaChangesAudit] 
WITH (STATE = ON);  
GO
*/