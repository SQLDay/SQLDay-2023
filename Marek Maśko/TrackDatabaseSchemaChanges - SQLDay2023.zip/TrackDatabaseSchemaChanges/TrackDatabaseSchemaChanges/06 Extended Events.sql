USE TrackMyChanges;
GO





-- Create Extended Event Session: CaptureSchemaChanges
-- using New Session Wizard...





CREATE TRIGGER dbo.tr_NewTableIns
ON dbo.NewTable
AFTER INSERT
AS
BEGIN
	SELECT 'Version 3';
END
GO

ALTER PROCEDURE dbo.usp_NewProc
AS
BEGIN
	SELECT 'Version 3';
END
GO

DROP FUNCTION dbo.fns_NewFun;



-----
--Use T-SQL QUERY to get events 

;WITH raw_data(t) AS
(
  SELECT CONVERT(XML, target_data)
  FROM sys.dm_xe_sessions AS s
  INNER JOIN sys.dm_xe_session_targets AS st
  ON s.[address] = st.event_session_address
  WHERE s.name = 'CaptureSchemaChanges'
  AND st.target_name = 'ring_buffer'
),
xml_data (ed) AS
(
  SELECT e.query('.') 
  FROM raw_data 
  CROSS APPLY t.nodes('RingBufferTarget/event') AS x(e)
)
SELECT * --FROM xml_data;

FROM
(
  SELECT
	[event_name]      = ed.value('(event/@name)[1]', 'nvarchar(128)'),
	[timestamp]       = ed.value('(event/@timestamp)[1]', 'datetime'),
	[database_id]     = ed.value('(event/data[@name="database_id"]/value)[1]', 'int'),
	[database_name]   = ed.value('(event/action[@name="database_name"]/value)[1]', 'nvarchar(128)'),
	[object_type]     = ed.value('(event/data[@name="object_type"]/text)[1]', 'nvarchar(128)'),
	[object_id]       = ed.value('(event/data[@name="object_id"]/value)[1]', 'int'),
    [object_name]     = ed.value('(event/data[@name="object_name"]/value)[1]', 'nvarchar(128)'),
	[session_id]      = ed.value('(event/action[@name="session_id"]/value)[1]', 'int'),
	[login]           = ed.value('(event/action[@name="server_principal_name"]/value)[1]', 'nvarchar(128)'),
	[client_hostname] = ed.value('(event/action[@name="client_hostname"]/value)[1]', 'nvarchar(128)'),
	[client_app_name] = ed.value('(event/action[@name="client_app_name"]/value)[1]', 'nvarchar(128)'),
	[sql_text]        = ed.value('(event/action[@name="sql_text"]/value)[1]', 'nvarchar(max)'),
    [phase]           = ed.value('(event/data[@name="ddl_phase"]/text)[1]',    'nvarchar(128)')
  FROM xml_data
) AS x
WHERE phase = 'Commit'
GO




/*
--Create Extended Event Session with T-SQL:
CREATE EVENT SESSION [CaptureSchemaChanges] ON SERVER 
ADD EVENT sqlserver.object_altered(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_id,sqlserver.database_name,sqlserver.server_principal_name,sqlserver.session_id,sqlserver.sql_text)), 
ADD EVENT sqlserver.object_created(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_id,sqlserver.database_name,sqlserver.server_principal_name,sqlserver.session_id,sqlserver.sql_text)), 
ADD EVENT sqlserver.object_deleted(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_id,sqlserver.database_name,sqlserver.server_principal_name,sqlserver.session_id,sqlserver.sql_text))
ADD TARGET package0.ring_buffer
WITH (STARTUP_STATE=OFF)
GO
*/